let stream, reader, recorder, timer, frame, canvasStream, closing, discard;
export function stopScan(){
 reader?.reset(); reader=null;
 stream?.getTracks().forEach(t=>t.stop()); stream=null;
}
export async function scan(video,onCode){
 stopScan();
 const {BrowserMultiFormatReader}=await import('./barcode-reader.js');
 reader=new BrowserMultiFormatReader();
 await reader.decodeFromConstraints({video:{facingMode:{ideal:'environment'}},audio:false},video,result=>{
  if(result && reader){stopScan();onCode(result.getText())}
 });
}
export function stopRecording(cancel=false){
 discard ||= cancel;
 if(recorder?.state==='recording')recorder.stop();
}
export async function record(video,lines,done,failed){
 if(!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream)throw Error('Watermarked recording requires a camera-enabled browser such as Android Chrome.');
 stopScan(); discard=false;
 const source=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720}},audio:false});
 try{
 video.srcObject=source;await video.play();
 const canvas=document.createElement('canvas');
 const scale=Math.min(1,1280/Math.max(video.videoWidth,video.videoHeight));
 canvas.width=Math.max(2,Math.floor(video.videoWidth*scale/2)*2);canvas.height=Math.max(2,Math.floor(video.videoHeight*scale/2)*2);
 const ctx=canvas.getContext('2d'),font=Math.max(15,Math.round(canvas.width/35));
 function draw(){
 ctx.drawImage(video,0,0,canvas.width,canvas.height);
 const labels=[...lines,new Date().toLocaleString('en-IN',{timeZone:'Asia/Kolkata',hour12:false})+' IST'];
 ctx.fillStyle='rgba(0,0,0,.76)';ctx.fillRect(0,canvas.height-(font+7)*labels.length-8,canvas.width,canvas.height);
 ctx.font=font+'px sans-serif';ctx.fillStyle='white';labels.forEach((l,i)=>ctx.fillText(l,8,canvas.height-(labels.length-1-i)*(font+7)-8,canvas.width-16));
 frame=requestAnimationFrame(draw);
 }
 draw(); canvasStream=canvas.captureStream(24);
 const type=['video/mp4;codecs=avc1','video/mp4;codecs=avc1.42E01E','video/mp4'].find(t=>MediaRecorder.isTypeSupported(t));
 if(!type)throw Error('This phone browser cannot record MP4 (Meesho accepts only MP4). Update Google Chrome and try again.');
 recorder=new MediaRecorder(canvasStream,{...(type?{mimeType:type}:{}),videoBitsPerSecond:1600000});
 const parts=[];recorder.ondataavailable=e=>{if(e.data.size)parts.push(e.data)};
 closing=()=>{clearTimeout(timer);cancelAnimationFrame(frame);source.getTracks().forEach(t=>t.stop());canvasStream?.getTracks().forEach(t=>t.stop());video.srcObject=null;recorder=null};
 recorder.onerror=()=>{discard=true;failed(Error('Recording interrupted. Record again.'));stopRecording(true)};
 recorder.onstop=()=>{const mime=recorder.mimeType;closing();if(!discard && parts.length)done(new File(parts,'unboxing.'+(mime.includes('mp4')?'mp4':'webm'),{type:mime.split(';')[0]}));else failed(Error('Recording discarded.'))};
 recorder.start(1000);timer=setTimeout(()=>stopRecording(),120000);
 }catch(e){cancelAnimationFrame(frame);source.getTracks().forEach(t=>t.stop());canvasStream?.getTracks().forEach(t=>t.stop());video.srcObject=null;throw e}
}
