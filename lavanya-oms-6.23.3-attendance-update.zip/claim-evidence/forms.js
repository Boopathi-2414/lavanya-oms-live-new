// Meesho Supplier Panel -> Support -> Returns/RTO & Exchange ticket forms (read from the panel 19 Nov 2026).
// path = /panel/v3/new/experience/<identifier>/support/<path>/create
// fields: state = State of the packet (Intact/Tampered), packetId = Packet ID (NA if none),
// logistics = Logistics Partner Name, note = Description (max 1000).
// slots: barcode = Barcode Image, label = Reverse Waybill, product = Image of product received,
// video = Unpacking Video (MP4), attachment = Attachments. "?" = optional.
// next = Meesho asks extra inputs on a second step after "Next".
export const COURIERS=['Delhivery','Bluedart','Ecom','Xpressbees','Shadowfax','Valmo','ElasticRun','ShipRocket','SWA'];
const CLAIM=['state','packetId','note','barcode?','label','product','video','attachment?'];
export const FORMS=[
 {path:'1/1',group:'Return claim (evidence)',issue:'I have received wrong return',fields:CLAIM},
 {path:'1/2',group:'Return claim (evidence)',issue:'Item/s are missing in my return',fields:CLAIM},
 {path:'1/3',group:'Return claim (evidence)',issue:'I have received damaged return',fields:CLAIM},
 {path:'1/4',group:'Return claim (evidence)',issue:'I have received used product as return',fields:CLAIM},
 {path:'1/139',group:'RTO claim (evidence)',issue:'I have received a wrong barcoded package in RTO',fields:['state','packetId','note','label','product','video','attachment?']},
 {path:'1/140',group:'RTO claim (evidence)',issue:'I have received an RTO in a non-barcoded package',fields:['state','note','label','product','video','attachment?']},
 {path:'1/6',group:'Delivery / logistics',issue:'Return/RTO product not received but marked delivered - Need Proof of Delivery',fields:['logistics','note?']},
 {path:'1/150',group:'Delivery / logistics',issue:'Return/RTO Delivery Issue - False Attempt by Logistic Partner',fields:['logistics','note?']},
 {path:'1/5',group:'Delivery / logistics',issue:'I have not received my Return/RTO shipment',fields:['note','attachment?'],next:true},
 {path:'1/8',group:'Exchange',issue:'I have an issue with Exchange order',fields:['note','attachment?'],next:true},
 {path:'1/72',group:'Exchange',issue:'I am not able to generate invoice for exchange order',fields:['note','attachment?'],next:true},
 {path:'1/172',group:'Other ticket',issue:'I am unable to raise Wrong Return / RTO claims',fields:['note','attachment?'],next:true},
 {path:'1/73',group:'Other ticket',issue:'Order return shipping charge fee issue',fields:['note','attachment?'],next:true},
 {path:'1/75',group:'Other ticket',issue:'When will I receive my wrong return related compensation',fields:['note','attachment?'],next:true},
 {path:'1/92',group:'Other ticket',issue:'I want to stop using the Wrong/Defective Returns Feature',fields:['note','attachment?'],next:true},
 {path:'1/252',group:'Other ticket',issue:'My order has been marked as Returnless Refund. What is Returnless Refund?',fields:['note','attachment?'],next:true},
 {path:'1/9',group:'Other ticket',issue:'Other Returns/RTO and Exchange related issue',fields:['note','attachment?'],next:true}
];
export function form(issue){return FORMS.find(f=>f.issue===issue)}
export function needs(f,key){if(!f)return 'no';if(f.fields.includes(key))return 'required';if(f.fields.includes(key+'?'))return 'optional';return 'no'}
