-- Run once as postgres in the existing OMS project's SQL Editor.
-- First create two secrets in Supabase Vault:
-- lavanya_evidence_owner_uid = actual OMS owner's Auth user UUID
-- lavanya_evidence_pin = a private, randomly chosen 8-12 digit PIN.
begin;
do $$ begin
 if not exists(select 1 from vault.decrypted_secrets v join auth.users u on u.id::text=v.decrypted_secret where v.name='lavanya_evidence_owner_uid')
 or not exists(select 1 from vault.decrypted_secrets where name='lavanya_evidence_pin' and decrypted_secret ~ '^[0-9]{8,12}$')
 then raise exception 'Configure the owner UID and PIN in Vault first'; end if;
 if exists(select 1 from storage.buckets where id='claim-evidence' and public) then raise exception 'Existing claim-evidence bucket is public. Review before continuing.'; end if;
end $$;
insert into storage.buckets(id,name,public) values('claim-evidence','claim-evidence',false) on conflict(id) do nothing;
create schema if not exists lavanya_evidence_private;
revoke all on schema lavanya_evidence_private from public,anon,authenticated;
create table if not exists lavanya_evidence_private.pin_gate(uid uuid primary key, next_try timestamptz, paths text[], until_at timestamptz);
create or replace function public.ce_owner() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vault.decrypted_secrets where name='lavanya_evidence_owner_uid' and decrypted_secret=auth.uid()::text)
$$;
create or replace function public.ce_delete_allowed(obj text) returns boolean language sql stable security definer set search_path='' as $$
 select public.ce_owner() and exists(select 1 from lavanya_evidence_private.pin_gate where uid=auth.uid() and until_at>now() and obj=any(paths))
$$;
drop policy if exists ce_read on storage.objects;
create policy ce_read on storage.objects for select to authenticated using(bucket_id='claim-evidence' and public.ce_owner());
drop policy if exists ce_upload on storage.objects;
create policy ce_upload on storage.objects for insert to authenticated with check(bucket_id='claim-evidence' and public.ce_owner() and split_part(name,'/',1)=auth.uid()::text);
drop policy if exists ce_remove on storage.objects;
create policy ce_remove on storage.objects for delete to authenticated using(bucket_id='claim-evidence' and public.ce_delete_allowed(name));
-- Keep any broader pre-existing policies from authorizing deletion in this bucket.
drop policy if exists ce_remove_guard on storage.objects;
create policy ce_remove_guard on storage.objects as restrictive for delete to public using(bucket_id<>'claim-evidence' or public.ce_delete_allowed(name));
drop policy if exists ce_read_guard on storage.objects;
create policy ce_read_guard on storage.objects as restrictive for select to authenticated using(bucket_id<>'claim-evidence' or public.ce_owner());
drop policy if exists ce_anon_guard on storage.objects;
create policy ce_anon_guard on storage.objects as restrictive for all to anon using(bucket_id<>'claim-evidence') with check(bucket_id<>'claim-evidence');
drop policy if exists ce_change_guard on storage.objects;
create policy ce_change_guard on storage.objects as restrictive for update to public using(bucket_id<>'claim-evidence') with check(bucket_id<>'claim-evidence');
create or replace function public.ce_match(code text) returns setof jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('id',o.id,'orderId',data->>'orderId','company',data->>'company','sku',data->>'sku','awb',data->>'awb','returnAwb',data->>'returnAwb','returnType',data->>'returnType','status',data->>'status','amount',data->>'amount','courier',data->>'courier')
 from public.oms_orders o where coalesce(data->>'deleted','false')<>'true' and length(trim(code)) between 1 and 180 and exists(
 select 1 from unnest(array[data->>'awb',data->>'returnAwb',data->>'orderId',data->>'invoice'] ||
 array(select jsonb_array_elements_text(case when jsonb_typeof(data->'altAwbs')='array' then data->'altAwbs' else '[]'::jsonb end))) a
 where upper(regexp_replace(a,'[-[:space:]]','','g'))=upper(regexp_replace(code,'[-[:space:]]','','g')))
 order by o.id
$$;
create or replace function public.ce_save(order_key text, target text, files jsonb, issue text, note text, form jsonb, amount numeric, due date)
returns text language plpgsql security invoker set search_path='' as $$
declare o jsonb; r jsonb; rid text; n int; f jsonb; stamp timestamptz:=clock_timestamp(); actor text:=auth.jwt()->>'email'; merged jsonb;
begin
 if not public.ce_owner() then raise exception 'OMS owner login required'; end if;
 select data into strict o from public.oms_orders where id=order_key and coalesce(data->>'deleted','false')<>'true' for update;
 if nullif(o->>'orderId','') is null then raise exception 'Order ID missing'; end if;
 select count(*),min(id) into n,rid from public.oms_business_records where data->>'kind'='claim' and data->>'orderId'=o->>'orderId' and coalesce(data->>'voided','false')<>'true' and coalesce(nullif(data->>'company',''),nullif(o->>'company',''),'Unknown company')=coalesce(nullif(o->>'company',''),'Unknown company');
 if target is not null then rid:=target;
 elsif n>1 then raise exception 'Choose the existing claim and retry'; end if;
 if rid is not null then
 select data into strict r from public.oms_business_records where id=rid and data->>'kind'='claim' and data->>'orderId'=o->>'orderId' and coalesce(data->>'voided','false')<>'true' and coalesce(nullif(data->>'company',''),nullif(o->>'company',''),'Unknown company')=coalesce(nullif(o->>'company',''),'Unknown company') for update;
 else
 if amount is null or amount<0 or due is null then raise exception 'Enter requested amount and actual deadline'; end if;
 rid:=gen_random_uuid()::text;
 r:=jsonb_build_object('id',rid,'kind','claim','orderId',o->>'orderId','company',coalesce(nullif(o->>'company',''),'Unknown company'),'reason',issue||' (Meesho)','requested',amount,'received',0,'deadline',due,'followUpDate','','notes','','status','To submit','evidence','','reference','','actor',actor,'at',stamp);
 end if;
 if r->>'evidenceStatus' in ('Filed','Deleted') or r->>'status' in ('Submitted','Under review','Part paid','Paid','Rejected','Closed') then raise exception 'Claim already filed or closed'; end if;
 if jsonb_typeof(files) is distinct from 'array' or nullif(trim(issue),'') is null then raise exception 'Missing evidence or issue'; end if;
 for f in select value from jsonb_array_elements(files) loop
 if f->>'slot' not in ('barcode','label','video','product','attachment') or not exists(select 1 from storage.objects where bucket_id='claim-evidence' and name=f->>'path' and split_part(name,'/',1)=auth.uid()::text) then raise exception 'Upload missing'; end if;
 end loop;
 select coalesce(jsonb_agg(item order by ord),'[]') into merged from (select distinct on (val->>'path') val as item, ord from jsonb_array_elements(coalesce(r->'evidenceFiles','[]')||files) with ordinality t(val,ord) order by val->>'path',ord) x;
 if jsonb_typeof(form) is distinct from 'object' or nullif(form->>'path','') is null then raise exception 'Meesho issue form missing'; end if;
 merged:=jsonb_build_object('evidenceFiles',merged,'evidenceStatus','Ready to file','meeshoIssue',issue,'problemNote',left(note,1000),'meeshoForm',form,'returnAwb',coalesce(nullif(o->>'returnAwb',''),o->>'awb'),'recordedBy',actor,'recordedAt',stamp);
 if n=0 then insert into public.oms_business_records(id,data,updated_at) values(rid,r||merged,stamp);
 else update public.oms_business_records set data=r||merged,updated_at=stamp where id=rid; end if;
 return rid;
end $$;
create or replace function public.ce_file(claim_id text, follow_up date, ref text default null) returns void language plpgsql security invoker set search_path='' as $$
declare r jsonb; patch jsonb:='{"evidenceStatus":"Filed"}';
begin
 select data into strict r from public.oms_business_records where id=claim_id and data->>'kind'='claim' and coalesce(data->>'voided','false')<>'true' for update;
 if r->>'evidenceStatus'='Filed' then return; end if;
 if r->>'evidenceStatus' is distinct from 'Ready to file' then raise exception 'Claim is not ready'; end if;
 if r->>'status'='To submit' then
 if follow_up is null then raise exception 'Next follow-up date required'; end if;
 patch:=patch||jsonb_build_object('status','Submitted','followUpDate',follow_up);
 end if;
 if nullif(trim(ref),'') is not null and nullif(r->>'reference','') is null then patch:=patch||jsonb_build_object('reference',trim(ref)); end if;
 update public.oms_business_records set data=r||patch,updated_at=clock_timestamp() where id=claim_id;
end $$;
create or replace function public.ce_unlock(claim_id text, pin text) returns boolean language plpgsql security definer set search_path='' as $$
declare allowed_paths text[]; gate lavanya_evidence_private.pin_gate; r jsonb;
begin
 if not public.ce_owner() then return false; end if;
 insert into lavanya_evidence_private.pin_gate(uid) values(auth.uid()) on conflict do nothing;
 select * into gate from lavanya_evidence_private.pin_gate where uid=auth.uid() for update;
 if gate.next_try>now() then return false; end if;
 update lavanya_evidence_private.pin_gate set next_try=now()+interval '30 seconds',paths=null,until_at=null where uid=auth.uid();
 if not exists(select 1 from vault.decrypted_secrets where name='lavanya_evidence_pin' and decrypted_secret=pin) then return false; end if;
 select data into r from public.oms_business_records where id=claim_id and data->>'kind'='claim' and data->>'evidenceStatus'='Filed' and (data->>'recordedAt')::timestamptz<now()-interval '30 days';
 if r is null then return false; end if;
 select array_agg(f->>'path') into allowed_paths from jsonb_array_elements(r->'evidenceFiles') f where split_part(f->>'path','/',1)=auth.uid()::text;
 if exists(select 1 from storage.objects s where s.bucket_id='claim-evidence' and s.name=any(allowed_paths) and s.created_at>=now()-interval '30 days') then return false; end if;
 update lavanya_evidence_private.pin_gate g set paths=allowed_paths,until_at=now()+interval '2 minutes',next_try=null where g.uid=auth.uid();
 return true;
end $$;
create or replace function public.ce_finish_delete(claim_id text) returns void language plpgsql security invoker set search_path='' as $$
declare r jsonb;
begin
 select data into strict r from public.oms_business_records where id=claim_id and data->>'kind'='claim' and data->>'evidenceStatus'='Filed' for update;
 if not public.ce_owner() or exists(select 1 from jsonb_array_elements(r->'evidenceFiles') f where not public.ce_delete_allowed(f->>'path') or exists(select 1 from storage.objects where bucket_id='claim-evidence' and name=f->>'path')) then raise exception 'Deletion incomplete. Retry cleanup.'; end if;
 update public.oms_business_records set data=r||'{"evidenceFiles":[],"evidenceStatus":"Deleted"}',updated_at=clock_timestamp() where id=claim_id;
end $$;
revoke execute on function public.ce_unlock(text,text),public.ce_delete_allowed(text),public.ce_owner(),public.ce_match(text),public.ce_save(text,text,jsonb,text,text,jsonb,numeric,date),public.ce_file(text,date,text),public.ce_finish_delete(text) from public,anon;
grant execute on function public.ce_unlock(text,text),public.ce_delete_allowed(text),public.ce_owner(),public.ce_match(text),public.ce_save(text,text,jsonb,text,text,jsonb,numeric,date),public.ce_file(text,date,text),public.ce_finish_delete(text) to authenticated;
commit;
