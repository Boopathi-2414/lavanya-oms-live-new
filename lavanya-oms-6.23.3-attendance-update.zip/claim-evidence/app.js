import {createClient} from './supabase.js';
import {project,publicKey} from './config.js';
import {scan,stopScan,record,stopRecording} from './camera.js';
import {FORMS,COURIERS,form,needs} from './forms.js';

const db=createClient(project,publicKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}});
const bucket=db.storage.from('claim-evidence');
const $=id=>document.getElementById(id);
const show=(id,on)=>{$(id).hidden=!on};
function say(message,error=false){$('message').textContent=message;$('message').classList.toggle('error',error)}
function unwrap(result){if(result.error)throw Error(result.error.message);return result.data}
async function rpc(name,args){return unwrap(await db.rpc(name,args))}
let session,order,claims=[],clip,clipUrl,busy=false,recording=false;
let uploaded=new WeakMap();
function run(fn){return async event=>{
 event?.preventDefault();if(busy)return;
 busy=true;
 const sections=['lookup','matches','evidence','login','queue','cleanup'];
 sections.forEach(id=>$(id).inert=true);
 try{await fn(event)}catch(e){say(e.message||String(e),true)}finally{busy=false;sections.forEach(id=>$(id).inert=false)}
}}
function elem(tag,text){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e}
function button(title,fn){const b=elem('button',title);b.type='button';b.onclick=run(fn);return b}
function reset(){
 stopScan();stopRecording(true);show('scanner',false);
 order=null;claims=[];clip=null;uploaded=new WeakMap();if(clipUrl)URL.revokeObjectURL(clipUrl);clipUrl=null;
 $('preview').removeAttribute('src');show('preview',false);show('evidence',false);show('matches',false);$('evidence').reset();
 $('videoStatus').textContent='Show all sides of the packet, the label (AWB, Order ID, barcode) and the Packet ID, then open it — one continuous take.';
 layout();
}
function dirty(){return clip||['barcode','label','product','attachment'].some(id=>$(id).files.length)||$('note').value}
{const sel=$('issue');let g=null,og;for(const f of FORMS){if(f.group!==g){g=f.group;og=document.createElement('optgroup');og.label=g;sel.append(og)}og.append(new Option(f.issue,f.issue))}
 COURIERS.forEach(c=>$('logistics').add(new Option(c,c)))}
function layout(){
 const f=form($('issue').value);
 document.querySelectorAll('[data-f]').forEach(el=>{const n=needs(f,el.dataset.f);el.hidden=n==='no';el.classList.toggle('req',n==='required')});
 $('issueHint').textContent=!f?'':(f.next?'Meesho will ask more details after "Next" — Claude fills that step while filing.':'')+(order&&/rto/i.test(order.returnType||'')&&f.group==='Return claim (evidence)'?' This parcel is an RTO — for RTO use the RTO claim options.':'')+(order&&!/rto/i.test(order.returnType||'')&&f.group==='RTO claim (evidence)'?' This parcel is a customer return, not RTO.':'');
}
$('issue').onchange=layout;
function leave(){return !recording && (!order||!dirty()||confirm('Discard unsaved evidence for this parcel?'))}
function applySession(next){
 if(!next)next=null;
 if(session?.user.id===next?.user.id && session && next && !$('workspace').hidden){session=next;return}
 session=next;reset();$('rows').replaceChildren();$('oldRows').replaceChildren();show('workspace',!!session);show('login',!session);
 say(session?'Checking OMS access…':'Sign in with your OMS account.');
 if(next){
  show('workspace',false);
  setTimeout(async()=>{
   try{
    const allowed=await rpc('ce_owner',{});
    if(session?.user.id!==next.user.id)return;
    if(!allowed)throw Error('This account does not match the configured OMS owner.');
    show('workspace',true);say('Signed in · '+session.user.email);await refresh();
   }catch(e){
    if(session?.user.id!==next.user.id)return;
    if($('workspace').hidden){show('login',true);say(e.message+' Check the one-time Supabase setup or sign in with the OMS owner email.',true)}
    else say(e.message,true);
   }
  },0);
 }
}
$('login').onsubmit=run(async()=>{unwrap(await db.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value}));$('password').value=''});
$('logout').onclick=run(async()=>{if(leave())unwrap(await db.auth.signOut({scope:'local'}))});
async function pages(build){
 let after=null;const rows=[];
 while(true){let q=build().order('id').limit(100);if(after!==null)q=q.gt('id',after);const batch=unwrap(await q);if(!batch.length)return rows;
 rows.push(...batch);after=batch.at(-1).id;
 }
}
function base(){return db.from('oms_business_records').select('id,data').eq('data->>kind','claim')}
function current(){return claims.find(c=>c.id===$('claim').value)?.data}
function adjust(){
 const c=current();show('newFields',!c);$('due').required=$('amount').required=!c;
 $('retained').textContent=c?.evidenceFiles?.length?c.evidenceFiles.length+' saved files will be kept.':'';
 $('issue').value=c?.meeshoIssue||'';$('note').value=c?.problemNote||'';$('packetId').value=c?.meeshoForm?.packetId||'NA';$('packetState').value=c?.meeshoForm?.state||'';$('logistics').value=c?.meeshoForm?.logistics||(order?.courier&&COURIERS.find(x=>x.toLowerCase().replace(/\s/g,'')===String(order.courier).toLowerCase().replace(/\s/g,'')))||'';layout();
}
async function choose(o){
 reset();
 order=o;
 claims=(await pages(()=>base().eq('data->>orderId',o.orderId))).filter(c=>!c.data.voided&&(!c.data.company||c.data.company===(o.company||'Unknown company')));
 if(claims.length && claims.every(c=>['Filed','Deleted'].includes(c.data.evidenceStatus)||['Submitted','Under review','Part paid','Paid','Rejected','Closed'].includes(c.data.status)))throw Error('This parcel already has a filed or closed claim.');
 $('parcel').textContent=o.orderId;$('detail').textContent=[o.company,o.sku,o.returnAwb||o.awb].filter(Boolean).join(' · ');
 $('claim').replaceChildren();
 if(!claims.length)$('claim').add(new Option('New claim',''));
 else {if(claims.length>1)$('claim').add(new Option('Choose existing claim',''));
 for(const c of claims){const opt=new Option([c.data.reason,c.data.status,c.id].join(' · '),c.id);opt.disabled=['Filed','Deleted'].includes(c.data.evidenceStatus)||['Submitted','Under review','Part paid','Paid','Rejected','Closed'].includes(c.data.status);$('claim').add(opt)}}
 adjust();if(!current()&&Number(o.amount)>0)$('amount').value=Number(o.amount);show('evidence',true);say('Confirm the parcel before recording.');
}
$('claim').onchange=adjust;
async function lookup(){
 const code=$('code').value.trim();if(!code)return;
 if(!leave())return;reset();
 const matches=await rpc('ce_match',{code});
 if(!matches.length)throw Error('No order matched. Check the AWB or enter the sub-order ID.');
 if(matches.length===1)return choose(matches[0]);
 $('choices').replaceChildren(...matches.map(o=>button([o.company,o.orderId,o.sku].join(' · '),()=>choose(o))));show('matches',true);say('Multiple matches. Choose the parcel.');
}
$('lookup').onsubmit=run(lookup);
$('scan').onclick=run(async()=>{
 if(recording)throw Error('Stop the recording first.');
 show('scanner',true);say('Point the camera at the parcel barcode.');
 try{await scan($('scanView'),value=>{show('scanner',false);$('code').value=value;setTimeout(()=>run(lookup)(),0)})}catch(e){stopScan();show('scanner',false);throw e}
});
$('closeScan').onclick=()=>{stopScan();show('scanner',false)};
function captureState(on){
 recording=on;show('record',!on);show('stop',on);
 $('lookup').inert=on;$('claim').disabled=on;
}
$('record').onclick=run(async()=>{
 if(!order)return;
 show('preview',true);$('preview').removeAttribute('src');$('preview').controls=false;
 await record($('preview'),['Lavanya OMS · '+order.orderId,'AWB '+(order.returnAwb||order.awb||'—'),session.user.email],file=>{
 clip=file;if(clipUrl)URL.revokeObjectURL(clipUrl);clipUrl=URL.createObjectURL(file);$('preview').src=clipUrl;$('preview').controls=true;
 captureState(false);$('videoStatus').textContent='Watermarked recording ready · '+(file.size/1048576).toFixed(1)+' MB';
 },err=>{captureState(false);say(err.message,true)});
 captureState(true);$('videoStatus').textContent='Recording · silent video · stops after 2 minutes.';
});
$('stop').onclick=()=>stopRecording();
window.addEventListener('pagehide',()=>{stopScan();stopRecording(true)});
async function shrink(file){
 if(!file.type.startsWith('image/')||(['image/jpeg','image/png'].includes(file.type)&&file.size<1.5*1048576))return file;
 try{const bmp=await createImageBitmap(file);const k=Math.min(1,1600/Math.max(bmp.width,bmp.height));const c=document.createElement('canvas');c.width=Math.round(bmp.width*k);c.height=Math.round(bmp.height*k);c.getContext('2d').drawImage(bmp,0,0,c.width,c.height);
 const b=await new Promise(r=>c.toBlob(r,'image/jpeg',0.8));return b?new File([b],file.name.replace(/\.[^.]+$/,'')+'.jpg',{type:'image/jpeg'}):file}catch(e){return file}
}
async function upload(slot,original){
 if(uploaded.has(original))return uploaded.get(original);
 const file=await shrink(original);
 if(!file.size || file.size>48*1048576)throw Error('Each file must be between 1 byte and 48 MB.');
 if(slot!=='video'&&!file.type.startsWith('image/')&&!(slot==='attachment'&&file.type==='application/pdf'))throw Error('Choose an image for '+slot);
 const ext=(file.name.split('.').pop()||'bin').replace(/[^a-z0-9]/gi,'').slice(0,8)||'bin';
 const path=session.user.id+'/'+crypto.randomUUID()+'.'+ext;
 unwrap(await bucket.upload(path,file,{contentType:file.type,upsert:false}));
 const meta={slot,path,name:file.name,type:file.type,size:file.size};uploaded.set(original,meta);return meta;
}
$('evidence').onsubmit=run(async()=>{
 if(recording)throw Error('Stop the recording before saving.');
 if(claims.length&&!current())throw Error('Choose a claim.');
 const f=form($('issue').value);if(!f)throw Error('Choose the Meesho issue.');
 const fields={barcode:[...$('barcode').files],label:[...$('label').files],video:clip?[clip]:[],product:[...$('product').files],attachment:[...$('attachment').files]};
 for(const k of Object.keys(fields))if(needs(f,k)==='no')fields[k]=[];
 const have=k=>fields[k].length||current()?.evidenceFiles?.some(x=>x.slot===k);
 for(const k of Object.keys(fields))if(needs(f,k)==='required'&&!have(k))throw Error('Required for this issue: '+{barcode:'Barcode Image',label:'Reverse Waybill photo',video:'Unpacking video',product:'Image of product received',attachment:'Attachment'}[k]);
 const pid=needs(f,'packetId')==='no'?'':($('packetId').value.trim()||'NA');
 if(pid&&pid.toUpperCase()!=='NA'&&needs(f,'barcode')!=='no'&&!have('barcode'))throw Error('Packet ID entered - add the Barcode Image (Packet ID photo).');
 if(needs(f,'state')==='required'&&!$('packetState').value)throw Error('Choose the state of the packet.');
 if(needs(f,'logistics')==='required'&&!$('logistics').value)throw Error('Choose the logistics partner.');
 if(needs(f,'note')==='required'&&!$('note').value.trim())throw Error('Write the description for Meesho.');
 const meeshoForm={path:f.path,issue:f.issue,next:!!f.next,state:needs(f,'state')==='no'?'':$('packetState').value,packetId:pid,logistics:needs(f,'logistics')==='no'?'':$('logistics').value,description:$('note').value.trim().slice(0,1000)};
 const files=[];
 for(const [slot,items] of Object.entries(fields))for(const file of items){say('Uploading '+slot+'…');files.push(await upload(slot,file))}
 await rpc('ce_save',{order_key:order.id,target:current()?.id||null,files,issue:$('issue').value,note:$('note').value.trim().slice(0,1000),form:meeshoForm,amount:current()?null:Number($('amount').value),due:current()?null:$('due').value});
 reset();$('code').value='';say('Evidence saved. Claim is ready to file.');await refresh();
});
async function list(status){
 if(!session)throw Error('Sign in to OMS first.');
 return (await pages(()=>base().eq('data->>evidenceStatus',status))).filter(c=>!c.data.voided);
}
async function queue(){
 const rows=await list('Ready to file');
 return Promise.all(rows.map(async({id,data})=>{
 const files=data.evidenceFiles||[];
 const signed=files.length?unwrap(await bucket.createSignedUrls(files.map(f=>f.path),900)):[];
 const urls=new Map(signed.map(x=>[x.path,x.signedUrl]));
 return {...data,id,evidenceFiles:files.map(f=>{if(!urls.get(f.path))throw Error('Unable to sign evidence for '+data.orderId);return {...f,signedUrl:urls.get(f.path)}})};
 }));
}
async function filed(id,followUpDate,reference=''){
 if(!session)throw Error('Sign in to OMS first.');
 await rpc('ce_file',{claim_id:id,follow_up:followUpDate||null,ref:reference||null});return true;
}
window.__LAVANYA_CLAIM_QUEUE__=queue;window.__LAVANYA_MARK_FILED__=filed;
async function refresh(){
 $('rows').replaceChildren();
 const rows=await queue();
 if(!rows.length)$('rows').append(elem('p','No claims ready to file.'));
 for(const c of rows){
 const a=elem('article');a.append(elem('h3',c.orderId),elem('p',[c.company,c.meeshoIssue,c.problemNote].filter(Boolean).join(' · ')));
 c.evidenceFiles.forEach(f=>{const link=elem('a',f.slot+' · '+f.name);link.href=f.signedUrl;link.target='_blank';link.rel='noreferrer';a.append(link)});
 const follow=elem('input');follow.type='date';follow.value=c.followUpDate||'';
 const fl=elem('label','Next follow-up');fl.append(follow);const ref=elem('input');ref.value=c.reference||'';
 const rl=elem('label','Marketplace reference (optional)');rl.append(ref);
 a.append(fl,rl,button('Mark filed',async()=>{if(c.status==='To submit'&&!follow.value)throw Error('Enter the next follow-up date.');
 if(!confirm('Already filed with the marketplace? Mark '+c.orderId+' as filed?'))return;
 await filed(c.id,follow.value,ref.value);await refresh();say('Marked filed.')}));$('rows').append(a);
 }
}
$('refresh').onclick=run(refresh);
async function old(){
 $('oldRows').replaceChildren();
 const rows=(await list('Filed')).filter(({data})=>Date.parse(data.recordedAt)<Date.now()-30*86400000);
 if(!rows.length)$('oldRows').append(elem('p','No eligible evidence.'));
 for(const {id,data} of rows){
 const a=elem('article');const files=data.evidenceFiles||[];const pin=elem('input');pin.type='password';pin.inputMode='numeric';pin.autocomplete='off';const label=elem('label','Owner PIN');label.append(pin);
 a.append(elem('h3',data.orderId),elem('p',files.length+' files · recorded '+data.recordedAt.slice(0,10)),label,button('Delete evidence',async()=>{
 if(!confirm('Permanently delete '+files.length+' evidence files for '+data.orderId+'?'))return;
 const value=pin.value;pin.value='';
 if(!await rpc('ce_unlock',{claim_id:id,pin:value}))throw Error('PIN or eligibility check failed. Wait 30 seconds before retrying.');
 for(let i=0;i<files.length;i+=100)unwrap(await bucket.remove(files.slice(i,i+100).map(f=>f.path)));
 await rpc('ce_finish_delete',{claim_id:id});await old();say('Old evidence deleted. Claim retained.');
 }));$('oldRows').append(a);
 }
}
$('old').onclick=run(old);
db.auth.onAuthStateChange((_event,next)=>applySession(next));
try{applySession(unwrap(await db.auth.getSession()).session)}catch(e){say(e.message,true)}
