export const project = "https://pgctafxsbcvrbqbqkzer.supabase.co";
export const publicKey = "sb_publishable_0ffbGTX9Ihr-EDDiUNcU1w_Bi_jErQJ";
