import {project,publicKey} from './config.js';
import {toMin,monthSoFar,streak,dayPay,rupees} from './pay.js';

const $=id=>document.getElementById(id);
const store={get(k){try{return localStorage.getItem(k)}catch{return null}},set(k,v){try{v==null?localStorage.removeItem(k):localStorage.setItem(k,v)}catch{}}};
function deviceId(){let d=store.get('lav_att_device');if(!d){d='ph-'+(crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2,14));store.set('lav_att_device',d)}return d}
const DEVICE=deviceId();
let token=store.get('lav_att_token'),me=null,offset=0,busy=false;

async function rpc(name,args){
 const r=await fetch(`${project}/rest/v1/rpc/${name}`,{method:'POST',headers:{apikey:publicKey,'Content-Type':'application/json'},body:JSON.stringify(args)});
 if(!r.ok){let m='Server error ('+r.status+')';try{const j=await r.json();m=j.message||m}catch{}throw Error(m)}
 return r.json();
}
function say(text,error=false){const m=$('message');m.hidden=!text;m.textContent=text||'';m.classList.toggle('error',error)}
const fmt12=hm=>{const m=toMin(hm);if(m==null)return'—';const h=Math.floor(m/60),mi=m%60;return`${(h%12)||12}:${String(mi).padStart(2,'0')} ${h<12?'AM':'PM'}`};
const minsText=n=>n>=60?`${Math.floor(n/60)} h ${n%60} min`:`${n} min`;
const pick=a=>a[Math.floor(Math.random()*a.length)];
const serverNow=()=>new Date(Date.now()+offset);
function istParts(d){const p=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).formatToParts(d);const g=t=>+p.find(x=>x.type===t).value;return{h:g('hour')%24,m:g('minute'),s:g('second')}}
const nowMin=()=>{const p=istParts(serverNow());return p.h*60+p.m};

function showLogin(){$('login').hidden=false;$('app').hidden=true;$('hello').textContent='';}
function signOut(){token=null;store.set('lav_att_token',null);me=null;showLogin()}

$('login').addEventListener('submit',async ev=>{
 ev.preventDefault();if(busy)return;busy=true;say('Signing in…');
 try{
  const r=await rpc('att_login',{p_code:$('code').value,p_pin:$('pin').value,p_device:DEVICE});
  if(!r.ok)throw Error(r.error);
  token=r.token;store.set('lav_att_token',token);$('pin').value='';say('');await load();
 }catch(e){say(e.message,true)}finally{busy=false}
});
$('logout').onclick=()=>{if(confirm('Sign out from this phone?'))signOut()};

async function load(){
 if(!token){showLogin();return}
 const r=await rpc('att_me',{p_token:token,p_device:DEVICE});
 if(!r.ok){if(r.signout){signOut();say(r.error,true)}else say(r.error,true);return}
 me=r;
 // server clock offset (server sends IST HH:MM:SS)
 const [h,m,s]=r.now.split(':').map(Number),loc=istParts(new Date());
 let diff=((h*3600+m*60+s)-(loc.h*3600+loc.m*60+loc.s));if(diff>43200)diff-=86400;if(diff<-43200)diff+=86400;offset=diff*1000;
 $('login').hidden=true;$('app').hidden=false;render();
}

function render(){
 if(!me)return;
 const T=me.terms,today=me.today,e=me.entries.find(x=>x.date===today);
 const first=(me.name||'').split(' ')[0];
 const hr=istParts(serverNow()).h;$('hello').textContent=`${hr<12?'Good morning':hr<16?'Good afternoon':'Good evening'}, ${first}`;
 $('date').textContent=new Date(today+'T00:00:00Z').toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',timeZone:'UTC'});
 const btn=$('punch');
 if(!T){$('shift').textContent='Shift not set yet — please ask the owner.';btn.disabled=true;btn.className='punch done';$('punchLabel').textContent='NOT READY';$('punchSub').textContent='';return}
 $('shift').textContent=`Your shift: ${fmt12(T.shiftStart)} – ${fmt12(T.shiftEnd)}`;
 const ownerEntry=e&&e.source!=='attendance-app';
 const hasIn=e&&e.in,hasOut=e&&e.out;
 btn.disabled=false;
 if(me.locked){btn.className='punch done';btn.disabled=true;$('punchLabel').textContent='CLOSED';$('punchSub').textContent='This month is closed by the owner'}
 else if(ownerEntry){btn.className='punch done';btn.disabled=true;$('punchLabel').textContent='RECORDED';$('punchSub').textContent='Entered by the owner'}
 else if(!hasIn){btn.className='punch in';$('punchLabel').textContent='CHECK IN';$('punchSub').textContent='Tap to mark your arrival'}
 else if(!hasOut){btn.className='punch out';$('punchLabel').textContent='CHECK OUT';$('punchSub').textContent='Tap when you leave'}
 else{btn.className='punch done';btn.disabled=true;$('punchLabel').textContent='DONE ✓';$('punchSub').textContent='See you tomorrow!'}
 $('locNote').textContent=me.sites?'':'Work places are not set yet. Your location is still saved.';
 // status
 const place=(site,inside)=>site==null?'':inside===false?`⚠️ Outside ${site}`:`📍 ${site}`;
 $('inTime').textContent=e?.actualIn?fmt12(e.actualIn):e?.in?fmt12(e.in):'—';
 $('outTime').textContent=e?.actualOut?fmt12(e.actualOut):e?.out?fmt12(e.out):'—';
 $('inPlace').textContent=place(e?.inSite,e?.inInside);$('inPlace').className=e?.inInside===false?'bad':'';
 $('outPlace').textContent=place(e?.outSite,e?.outInside);$('outPlace').className=e?.outInside===false?'bad':'';
 // money
 const nm=nowMin(),M=monthSoFar(T,me.month,today,me.entries,nm,me.joiningDate);
 const td=M.rows.find(r=>r.date===today);
 $('todayPay').textContent=rupees(td?td.pay:0);
 $('todayNote').textContent=!e?(td&&td.off?'Weekly off — paid holiday':'Check in to start earning'):td?.open?`Earning now · ${minsText(td.worked)} worked`:td?.status==='Weekly off'?'Weekly off':td?.worked?`${minsText(td.worked)} worked`:'';
 $('monthPay').textContent=rupees(M.total);
 $('daysPresent').textContent=M.present;
 $('advance').textContent=rupees(me.advanceThisMonth);
 const st=streak(T,me.entries,today,me.grace);$('streak').textContent=st?`🔥 ${st} day${st>1?'s':''}`:'0';
 // missing OUT on an earlier day
 const miss=me.entries.filter(x=>x.date<today&&x.in&&!x.out&&x.source==='attendance-app'&&x.status==='Present').map(x=>x.date).slice(-3);
 $('warn').hidden=!miss.length;
 if(miss.length)$('warn').textContent=`You did not CHECK OUT on ${miss.map(d=>new Date(d+'T00:00:00Z').toLocaleDateString('en-IN',{day:'numeric',month:'short',timeZone:'UTC'})).join(', ')}. Please tell the owner your leaving time.`;
 // last 7 days
 const list=$('days');list.replaceChildren();
 const d0=new Date(today+'T00:00:00Z');
 for(let k=0;k<7;k++){
  const d=new Date(d0);d.setUTCDate(d.getUTCDate()-k);const date=d.toISOString().slice(0,10);
  const x=me.entries.find(y=>y.date===date),Tm=date.slice(0,7)===me.month?T:(me.prevTerms||T);
  const r=dayPay(Tm,date,x,{nowMin:nm,isToday:date===today});
  const row=document.createElement('div');row.className='day';
  const a=document.createElement('span');a.className='t';a.textContent=d.toLocaleDateString('en-IN',{weekday:'short',day:'numeric',timeZone:'UTC'});
  const b=document.createElement('span');
  if(x?.in){b.textContent=`${fmt12(x.actualIn||x.in)} – ${x.out?fmt12(x.actualOut||x.out):'…'}`;
   const sS=toMin(Tm.shiftStart);const tag=document.createElement('span');
   if(x.status==='Weekly off'){tag.className='tag';tag.textContent='Sunday work'}
   else if(toMin(x.actualIn||x.in)<=sS+me.grace){tag.className='tag star';tag.textContent='★ on time'}
   else{tag.className='tag late';tag.textContent=`${toMin(x.actualIn||x.in)-sS} min late`}
   b.append(' ',tag);
  }else b.textContent=x?.status||(r.off?'Weekly off':date===today?'Not yet':'Absent');
  const c=document.createElement('b');c.textContent=rupees(r.pay);
  row.append(a,b,c);list.append(row);
 }
}

function getLocation(){
 return new Promise((res,rej)=>{
  if(!navigator.geolocation)return rej(Error('This phone cannot share location. Use Chrome.'));
  navigator.geolocation.getCurrentPosition(p=>res(p.coords),err=>{
   rej(Error(err.code===1?'Location permission is blocked. Tap the 🔒 icon near the address bar → Permissions → Location → Allow, then try again.':err.code===3?'Location is taking too long. Go near a window or outside and try again.':'Could not get location. Turn ON Location (GPS) in your phone settings and try again.'))
  },{enableHighAccuracy:true,timeout:20000,maximumAge:0});
 });
}

const CHEER_EARLY=['Superb! You are early today 🌟','Wow, early bird! 🐦','Excellent start to the day! 🌟'];
const CHEER_ONTIME=['Excellent, {n}! Right on time 🌟','Perfect timing, {n}! 👏','Great job, {n}! On time again ⭐'];
const CHEER_OUT=['Thank you for today, {n}! 🙏','Well done today, {n}! 💪','Great work today, {n}! ✨'];
function cheer(icon,title,text,late=false){$('cheer').hidden=false;$('cheer').classList.toggle('late',late);$('cheerIcon').textContent=icon;$('cheerTitle').textContent=title;$('cheerText').textContent=text;$('cheerIcon').style.animation='none';void $('cheerIcon').offsetWidth;$('cheerIcon').style.animation='';$('cheer').scrollIntoView({behavior:'smooth',block:'center'})}

$('punch').onclick=async()=>{
 if(busy||!me)return;const T=me.terms,e=me.entries.find(x=>x.date===me.today),kind=e&&e.in?'out':'in';
 if(kind==='out'){const sE=toMin(T.shiftEnd),nm=nowMin();if(nm<sE&&!confirm(`Your shift ends at ${fmt12(T.shiftEnd)}. Leaving ${sE-nm} min early will reduce today's pay. Check OUT now?`))return}
 busy=true;const btn=$('punch');btn.classList.add('busy');btn.disabled=true;$('locNote').textContent='📍 Getting your location…';say('');
 try{
  const c=await getLocation();$('locNote').textContent=`📍 Location found (±${Math.round(c.accuracy)} m). Saving…`;
  const r=await rpc('att_punch',{p_token:token,p_device:DEVICE,p_kind:kind,p_lat:c.latitude,p_lng:c.longitude,p_acc:c.accuracy});
  if(!r.ok){if(r.signout){signOut()}throw Error(r.error)}
  const n=(me.name||'').split(' ')[0];
  const where=r.inside===false?` ⚠️ You are ${r.dist} m away from ${r.site} — the owner will see this.`:'';
  if(kind==='in'){
   if(r.weeklyOff)cheer('🙌',`Thank you for coming on your day off, ${n}!`,`IN at ${fmt12(r.time)}.${where}`);
   else if(r.early>0)cheer('🌟',pick(CHEER_EARLY).replace('{n}',n),`IN at ${fmt12(r.time)} — ${r.early} min before your shift.${where}`);
   else if(r.onTime)cheer('🌟',pick(CHEER_ONTIME).replace('{n}',n),`IN at ${fmt12(r.time)}.${where}`);
   else cheer('⏰',`You are ${minsText(r.late)} late today`,`IN at ${fmt12(r.time)}. No problem — let's be on time tomorrow! 💪${where}`,true);
  }else{
   const extra=r.extra>0?` +${minsText(r.extra)} extra time added.`:r.earlyLeave>0?` Left ${minsText(r.earlyLeave)} early.`:'';
   cheer('✅',pick(CHEER_OUT).replace('{n}',n),`OUT at ${fmt12(r.time)}. Today's earning ${rupees(r.pay)}.${extra}${where}`);
  }
  await load();
 }catch(err){say(err.message,true);render()}
 finally{busy=false;btn.classList.remove('busy')}
};

setInterval(()=>{const p=istParts(serverNow());$('clock').textContent=`${(p.h%12)||12}:${String(p.m).padStart(2,'0')}:${String(p.s).padStart(2,'0')} ${p.h<12?'AM':'PM'}`;if(p.s===0&&!busy)render()},1000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&token&&!busy)load().catch(e=>say(e.message,true))});
load().catch(e=>say(e.message,true));
