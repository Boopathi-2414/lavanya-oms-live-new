import {createClient} from './supabase.js';
import {project,publicKey} from './config.js';
import {toMin,dayPay,dim,weekday} from './pay.js';

const db=createClient(project,publicKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}});
const $=id=>document.getElementById(id);
let data=null,busy=false;
function say(t,err=false){const m=$('message');m.hidden=!t;m.textContent=t||'';m.classList.toggle('error',err)}
async function rpc(name,args={}){const r=await db.rpc(name,args);if(r.error)throw Error(r.error.message);return r.data}
const fmt12=hm=>{const m=toMin(hm);if(m==null)return'—';const h=Math.floor(m/60);return`${(h%12)||12}:${String(m%60).padStart(2,'0')} ${h<12?'AM':'PM'}`};
const el=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=text;return e};
const btn=(text,cls,fn)=>{const b=el('button','mini '+(cls||''),text);b.type='button';b.onclick=()=>run(fn);return b};
async function run(fn){if(busy)return;busy=true;try{await fn()}catch(e){say(e.message||String(e),true)}finally{busy=false}}

async function start(){
 const {data:{session}}=await db.auth.getSession();
 if(!session){$('login').hidden=false;$('app').hidden=true;return}
 $('login').hidden=true;$('app').hidden=false;await refresh();
}
$('login').addEventListener('submit',ev=>{ev.preventDefault();run(async()=>{
 const r=await db.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});
 if(r.error)throw Error(r.error.message);$('password').value='';say('');await start();
})});
$('logout').onclick=()=>run(async()=>{await db.auth.signOut();location.reload()});
$('refresh').onclick=()=>run(refresh);

async function refresh(){
 data=await rpc('att_admin_list');say('');
 $('today').textContent=new Date(data.today+'T00:00:00Z').toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short',timeZone:'UTC'});
 $('grace').value=data.settings.grace;$('early').value=data.settings.earlyCap;
 board();logins();places();fillStaffPicker();
 if(!ed||ed.staff.staffId!==$('eStaff').value)await loadMonth();
}

function place(loc){if(!loc)return'';if(loc.inside===false)return`⚠️ ${loc.dist} m from ${loc.site}`;if(loc.site)return`📍 ${loc.site}`;return'📍 place not set'}
function board(){
 const box=$('boardRows');box.replaceChildren();
 for(const s of data.staff){
  const r=s.todayRec,T=s.terms,row=el('div','row'),top=el('div','top');
  top.append(el('b',null,s.name));
  let chip;
  if(!T)chip=el('span','chip wait','no shift');
  else if(!r)chip=el('span','chip wait','not in yet');
  else if(r.status==='Weekly off')chip=el('span','chip','weekly off'+(r.in?' · worked':''));
  else{const late=r.actualIn?toMin(r.actualIn)-toMin(T.shiftStart):0;chip=late>data.settings.grace?el('span','chip late',`${late} min late`):el('span','chip ok',r.out?'done':'in · on time')}
  top.append(chip);row.append(top);
  if(T)row.append(el('div','meta',`Shift ${fmt12(T.shiftStart)} – ${fmt12(T.shiftEnd)}`));
  if(r){
   row.append(el('div','meta',`IN ${fmt12(r.actualIn||r.in)}${r.actualIn&&r.in&&r.in!==r.actualIn?` (paid from ${fmt12(r.in)})`:''} ${place(r.inLoc)}   ·   OUT ${r.out?fmt12(r.actualOut||r.out):'—'} ${place(r.outLoc)}`));
   if(r.source!=='attendance-app')row.append(el('div','meta','Entered in OMS Payroll'));
   const links=el('div','acts');
   for(const [k,loc] of [['IN',r.inLoc],['OUT',r.outLoc]])if(loc&&loc.lat!=null){const a=el('a','mini',`Map ${k}`);a.href=`https://www.google.com/maps?q=${loc.lat},${loc.lng}`;a.target='_blank';a.rel='noopener';links.append(a)}
   links.childElementCount&&row.append(links);
  }
  box.append(row);
 }
 if(!data.staff.length)box.append(el('p','hint','No active employees in OMS Payroll yet.'));
}

function waText(s,code,pin){return `Lavanya's Mart attendance\nOpen in Chrome: ${location.origin}/attendance/\nEmployee ID: ${code}\nPIN: ${pin}\nTap CHECK IN when you arrive and CHECK OUT when you leave. Keep Location ON.`}
function logins(){
 const box=$('loginRows');box.replaceChildren();
 for(const s of data.staff){
  const row=el('div','row'),top=el('div','top');
  top.append(el('b',null,s.name),el('span','chip '+(s.login?(s.loginActive?'ok':'bad'):'wait'),s.login?(s.loginActive?'login ready':'turned off'):'no PIN yet'));
  row.append(top,el('div','meta',`Employee ID: ${s.code||'— (set it in OMS Payroll)'} · Phone: ${s.phone?'linked':'not linked yet'}${s.lockedUntil&&new Date(s.lockedUntil)>new Date()?' · locked (wrong PINs)':''}`));
  const acts=el('div','acts');
  acts.append(btn(s.login?'New PIN':'Set PIN','primary',async()=>{
   const sug=String(Math.floor(1000+Math.random()*9000));
   const pin=prompt(`4-digit PIN for ${s.name}`,sug);if(pin==null)return;
   if(!/^\d{4}$/.test(pin))throw Error('PIN must be exactly 4 digits');
   const code=await rpc('att_admin_set_pin',{p_staff:s.staffId,p_pin:pin});
   const msg=waText(s,code,pin);
   try{await navigator.clipboard.writeText(msg);say(`PIN saved for ${s.name}. Login message copied — paste it in WhatsApp.`)}catch{say(`PIN saved for ${s.name}.`)}
   if(confirm('Open WhatsApp to send the login message?'))window.open('https://wa.me/?text='+encodeURIComponent(msg),'_blank','noopener');
   await refresh();
  }));
  if(s.login){
   acts.append(btn('Reset phone','',async()=>{if(!confirm(`Unlink ${s.name}'s phone? They can then sign in on a new phone.`))return;await rpc('att_admin_reset_phone',{p_staff:s.staffId});say('Phone unlinked');await refresh()}));
   acts.append(btn(s.loginActive?'Turn off':'Turn on',s.loginActive?'danger':'',async()=>{await rpc('att_admin_set_active',{p_staff:s.staffId,p_active:!s.loginActive});await refresh()}));
  }
  row.append(acts);box.append(row);
 }
}

function places(){
 const box=$('placeRows');box.replaceChildren();
 for(const name of ['Godown','Shop']){
  const p=data.sites.find(x=>x.name===name),row=el('div','row'),top=el('div','top');
  top.append(el('b',null,name),el('span','chip '+(p?'ok':'wait'),p?`saved · ${p.radius} m`:'not set'));row.append(top);
  if(p){const a=el('a','mini','View on map');a.href=`https://www.google.com/maps?q=${p.lat},${p.lng}`;a.target='_blank';a.rel='noopener';row.append(el('div','meta',`${p.lat.toFixed(6)}, ${p.lng.toFixed(6)}`),a)}
  const acts=el('div','acts'),rad=el('input');rad.type='number';rad.min=30;rad.max=1000;rad.value=p?p.radius:100;rad.title='Radius in metres';
  acts.append(rad,btn('Save my location','primary',async()=>{
   say('📍 Getting this phone\'s location…');
   const c=await new Promise((res,rej)=>navigator.geolocation.getCurrentPosition(x=>res(x.coords),e=>rej(Error('Location not available: '+e.message)),{enableHighAccuracy:true,timeout:25000,maximumAge:0}));
   if(c.accuracy>80&&!confirm(`GPS accuracy is only ±${Math.round(c.accuracy)} m. Save anyway? (Better: wait a minute near a window and try again.)`))return say('');
   await rpc('att_admin_set_site',{p_name:name,p_lat:c.latitude,p_lng:c.longitude,p_radius:Number(rad.value)||100});
   say(`${name} saved (±${Math.round(c.accuracy)} m).`);await refresh();
  }));
  row.append(acts);box.append(row);
 }
}
// ---------- Edit days ----------
let ed=null,draft=new Map();
const STATUSES=['Present','Half day','Absent','Leave','Holiday','Weekly off'];
const istToday=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata'}).format(new Date());
function fillStaffPicker(){
 const sel=$('eStaff'),cur=sel.value;sel.replaceChildren();
 for(const s of data.staff){const o=el('option',null,`${s.name}${s.code?' ('+s.code+')':''}`);o.value=s.staffId;sel.append(o)}
 if(cur&&data.staff.some(s=>s.staffId===cur))sel.value=cur;
 if(!$('eMonth').value)$('eMonth').value=istToday().slice(0,7);
}
async function loadMonth(){
 if(!$('eStaff').value||!$('eMonth').value)return;
 ed=await rpc('att_admin_month',{p_staff:$('eStaff').value,p_month:$('eMonth').value});draft=new Map();
 $('eJoin').value=ed.staff.joiningDate||'';
 const m=ed.staff&&$('eMonth').value;$('bFrom').value=`${m}-01`;$('bTo').value=ed.today.startsWith(m)?ed.today:`${m}-${String(dim(m)).padStart(2,'0')}`;
 drawMonth();
}
function cur(date){const e=ed.entries.find(x=>x.date===date),d=draft.get(date);return d?{...(e||{}),...d,_changed:true}:e?{...e}:null}
function drawMonth(){
 const box=$('eRows');box.replaceChildren();const T=ed.terms,mo=$('eMonth').value;
 if(!T){box.append(el('p','hint','No shift/salary for this month yet — set it in OMS Payroll first.'));$('eSave').disabled=true;$('eSummary').textContent='';return}
 if(ed.locked)box.append(el('p','warn','This month is locked (salary paid). Edit it in OMS Payroll with the owner PIN.'));
 const head=el('div','drow head');['Day','Status · IN / OUT','','','₹ (est.)'].forEach(t=>head.append(el('span',null,t)));box.append(head);
 const last=ed.today.startsWith(mo)?+ed.today.slice(8,10):ed.today<mo?0:dim(mo);
 let li=0,total=0,leaves=0,absent=0,present=0;
 for(let k=1;k<=last;k++){
  const date=`${mo}-${String(k).padStart(2,'0')}`,e=cur(date),off=(T.weeklyOff||[0]).map(Number).includes(weekday(date));
  const before=ed.staff.joiningDate&&date<ed.staff.joiningDate;
  if(e?.status==='Leave')li++;
  const r=before?{pay:0}:dayPay(T,date,e||undefined,{leaveIdx:li});
  total+=r.pay;if(e?.status==='Leave')leaves++;if(e?.status==='Absent')absent++;if(e?.status==='Present'||e?.status==='Half day')present++;
  const row=el('div','drow'+(e?._changed?' changed':'')+(off?' off':''));
  const d=el('span','d',String(k));d.append(el('small',null,new Date(date+'T00:00:00Z').toLocaleDateString('en-IN',{weekday:'short',timeZone:'UTC'})));
  const sel=el('select');const o0=el('option',null,before?'not joined':off?'Weekly off (auto)':'— no entry');o0.value='';sel.append(o0);
  for(const s of STATUSES){const o=el('option',null,s);o.value=s;sel.append(o)}
  sel.value=e?.status||'';sel.disabled=ed.locked;
  const tin=el('input'),tout=el('input');tin.type=tout.type='time';tin.className='ti';tout.className='to';tin.title='IN';tout.title='OUT';tin.value=e?.in||'';tout.value=e?.out||'';
  const timed=['Present','Half day'].includes(sel.value);tin.disabled=tout.disabled=!timed||ed.locked;
  const upd=()=>{const st=sel.value,tm=['Present','Half day'].includes(st);
   if(tm&&!tin.value)tin.value=T.shiftStart;if(tm&&!tout.value&&date<ed.today)tout.value=T.shiftEnd;
   draft.set(date,{status:st,in:tm?tin.value:'',out:tm?tout.value:'',note:e?.note||''});drawMonth()};
  sel.onchange=upd;tin.onchange=upd;tout.onchange=upd;
  row.append(d,sel,tin,tout,el('span','p',before?'—':Math.round(r.pay).toLocaleString('en-IN')));
  if(e&&(e.source==='attendance-app'||e.note)){const src=el('span','src',[e.source==='attendance-app'?`📱 app: IN ${e.actualIn?fmt12(e.actualIn):'—'} ${place(e.inLoc)} · OUT ${e.actualOut?fmt12(e.actualOut):'—'}`:'',e.note||''].filter(Boolean).join(' · '));row.append(src)}
  box.append(row);
 }
 $('eSummary').textContent=`${ed.staff.name} · ${mo}: present ${present}, leave ${leaves}, absent ${absent} · estimated gross ₹${Math.round(total).toLocaleString('en-IN')} (final figure in OMS Payroll)`;
 $('eSave').disabled=!draft.size||ed.locked;$('eSave').textContent=draft.size?`Save changes (${draft.size} day${draft.size>1?'s':''})`:'Save changes';
}
$('eStaff').onchange=()=>run(loadMonth);$('eMonth').onchange=()=>run(loadMonth);
$('bApply').onclick=()=>{
 if(!ed?.terms)return say('Pick an employee with a shift first',true);
 const mo=$('eMonth').value,f=$('bFrom').value,t=$('bTo').value,st=$('bStatus').value,T=ed.terms;
 if(!f||!t||f>t)return say('Choose From and To dates',true);
 let n=0;
 for(let k=1;k<=dim(mo);k++){const date=`${mo}-${String(k).padStart(2,'0')}`;
  if(date<f||date>t||date>ed.today)continue;
  if(ed.staff.joiningDate&&date<ed.staff.joiningDate)continue;
  if($('bSkipOff').checked&&(T.weeklyOff||[0]).map(Number).includes(weekday(date)))continue;
  if($('bSkipFilled').checked&&ed.entries.some(x=>x.date===date))continue;
  const tm=['Present','Half day'].includes(st);
  draft.set(date,{status:st,in:tm?$('bIn').value:'',out:tm?$('bOut').value:'',note:''});n++;
 }
 say(n?`${n} day(s) filled as ${st}. Check them, then tap Save changes.`:'No days to fill (all already have attendance, or outside the month).');drawMonth();
};
$('eSave').onclick=()=>run(async()=>{
 const rows=[...draft.entries()].map(([date,d])=>({date,...d}));
 if(!confirm(`Save ${rows.length} day(s) for ${ed.staff.name}?`))return;
 const n=await rpc('att_admin_save_days',{p_staff:ed.staff.staffId,p_rows:rows});
 say(`Saved ${n} day(s) for ${ed.staff.name}. OMS Payroll is updated.`);await loadMonth();
});
$('eJoinSave').onclick=()=>run(async()=>{await rpc('att_admin_set_joining',{p_staff:$('eStaff').value,p_date:$('eJoin').value});say('Joining date saved');await loadMonth()});

$('saveRules').onclick=()=>run(async()=>{await rpc('att_admin_settings',{p_grace:Number($('grace').value),p_early:Number($('early').value)});say('Rules saved');await refresh()});
start().catch(e=>say(e.message,true));
