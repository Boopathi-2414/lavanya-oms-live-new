// Same pay rules as OMS Payroll (lpDay / lpRates), used only to SHOW the employee their earnings.
// The OMS Payroll page stays the final word on salary.
export const toMin=t=>{const m=String(t||'').trim().match(/^(\d{1,2})[:.]?(\d{2})$/);if(!m)return null;const h=+m[1],mi=+m[2];return h<24&&mi<60?h*60+mi:null};
export const dim=month=>{const[y,m]=month.split('-').map(Number);return new Date(Date.UTC(y,m,0)).getUTCDate()};
export const weekday=date=>new Date(date+'T00:00:00Z').getUTCDay();
export function rates(T,month){
 const s=toMin(T.shiftStart),e=toMin(T.shiftEnd),shiftMin=Math.max(1,(e-s)-(Number(T.unpaidBreak)||0));
 const daily=(Number(T.monthlySalary)||0)/dim(month);return{daily,perMin:daily/shiftMin,shiftMin};
}
// e = attendanceDay entry (or undefined); nowMin = current minute for an open (not yet OUT) day today
export function dayPay(T,date,e,{leaveIdx=0,nowMin=null,isToday=false}={}){
 const off=(T.weeklyOff||[0]).map(Number).includes(weekday(date)),R=rates(T,date.slice(0,7));
 let status=e?e.status:'';if(!status&&off)status='Weekly off';
 const r={date,off,status,in:e?.in||'',out:e?.out||'',worked:0,pay:0,open:false};
 const sS=toMin(T.shiftStart),sE=toMin(T.shiftEnd),i=toMin(r.in),o=toMin(r.out),brk=Number(T.unpaidBreak)||0;
 const timed=full=>{
  if(i!=null&&o==null&&isToday&&nowMin!=null){r.open=true;let w=Math.max(0,nowMin-i-brk);T.payExtra===false&&(w=Math.min(w,R.shiftMin));r.worked=w;r.pay=w*R.perMin;return}
  if(i!=null&&o!=null&&o<=i)return;
  if(i==null||o==null){if(full){r.worked=R.shiftMin;r.pay=R.daily;r.missingOut=i!=null&&o==null}return}
  let w=Math.max(0,o-i-brk);T.payExtra===false&&(w=Math.min(w,R.shiftMin));r.worked=w;r.pay=w*R.perMin;r.extra=Math.max(0,o-sE);r.late=Math.max(0,i-sS);
 };
 if(status==='Present')timed(true);
 else if(status==='Half day'){timed(false);if(i==null||o==null){r.worked=Math.round(R.shiftMin/2);r.pay=R.daily/2}}
 else if(status==='Weekly off')r.pay=T.weeklyOffPaid===false?0:R.daily;
 else if(status==='Leave')r.pay=leaveIdx<=(Number(T.paidLeaveDays)||0)?R.daily:0;
 else if(status==='Holiday')r.pay=e?.paidHoliday?R.daily:0;
 return r;
}
// Month so far: every date of the month up to today
export function monthSoFar(T,month,today,entries,nowMin,joiningDate){
 const byDate=new Map(entries.filter(e=>e.date.startsWith(month)).map(e=>[e.date,e]));
 const last=today.startsWith(month)?+today.slice(8,10):dim(month);
 let li=0,total=0,present=0;const rows=[];
 for(let d=1;d<=last;d++){
  const date=`${month}-${String(d).padStart(2,'0')}`;if(joiningDate&&date<joiningDate)continue;
  const e=byDate.get(date);if(e?.status==='Leave')li++;
  const r=dayPay(T,date,e,{leaveIdx:li,nowMin,isToday:date===today});
  // today without an entry is not counted yet
  if(date===today&&!e&&!r.off){rows.push(r);continue}
  total+=r.pay;(r.status==='Present'||r.status==='Half day')&&present++;rows.push(r);
 }
 return{total,present,rows};
}
// on-time streak: working days in a row with IN on time (within grace); off days are skipped
export function streak(T,entries,today,grace){
 const byDate=new Map(entries.map(e=>[e.date,e])),sS=toMin(T.shiftStart);let n=0;
 const d=new Date(today+'T00:00:00Z');
 for(let k=0;k<62;k++){
  const date=d.toISOString().slice(0,10),e=byDate.get(date),off=(T.weeklyOff||[0]).map(Number).includes(d.getUTCDay());
  d.setUTCDate(d.getUTCDate()-1);
  if(off&&!(e&&e.actualIn))continue;
  if(!e||!e.actualIn){if(date===today)continue;break}
  if(e.status==='Weekly off')continue;
  if(toMin(e.actualIn)<=sS+grace)n++;else break;
 }
 return n;
}
export const rupees=v=>'₹'+(Math.round((v||0)*100)/100).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
